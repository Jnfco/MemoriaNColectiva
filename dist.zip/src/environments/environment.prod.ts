export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyDqf1Q3jwbbN0beXBHNAzhVhwx-Me2ND0k",
    authDomain: "negociacioncolectiva-80355.firebaseapp.com",
    databaseURL: "https://negociacioncolectiva-80355.firebaseio.com",
    projectId: "negociacioncolectiva-80355",
    storageBucket: "negociacioncolectiva-80355.appspot.com",
    messagingSenderId: "714664163559",
    appId: "1:714664163559:web:e592d03847adad55788a42",
  }
};
