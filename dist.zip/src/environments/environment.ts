// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyDqf1Q3jwbbN0beXBHNAzhVhwx-Me2ND0k",
    authDomain: "negociacioncolectiva-80355.firebaseapp.com",
    databaseURL: "https://negociacioncolectiva-80355.firebaseio.com",
    projectId: "negociacioncolectiva-80355",
    storageBucket: "negociacioncolectiva-80355.appspot.com",
    messagingSenderId: "714664163559",
    appId: "1:714664163559:web:e592d03847adad55788a42",
  },
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
