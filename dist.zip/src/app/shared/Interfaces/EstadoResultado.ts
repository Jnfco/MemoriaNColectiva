export interface EstadoR{
  anio:string;
  ingresos: string;
  costoVentas:string;
  margen:string;
  otrosI:string;
  gastosAdm:string;
  otrasGanancias:string;
  ingresosF:string;
  a:string;
  costosF:string;
}
