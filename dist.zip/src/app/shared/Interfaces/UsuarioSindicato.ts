export interface UsuarioSindicato {
    nombre: string;
    correo: string;
    pass: string;
    idSindicato:string;
  }