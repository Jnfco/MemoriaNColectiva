export interface InactiveUser {
    nombre: string;
    correo: string;
    pass: string;
    idSindicato:string;
    organization:string;
    isAdmin:boolean;
  }