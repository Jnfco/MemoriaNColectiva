import { UsuarioSindicato } from './UsuarioSindicato';

export class Sindicato{
    nombre: string;
    idAdmin: string;
    usuarios: UsuarioSindicato [];
    cantidadMiembros:number;
    idFundacion:string;
  }
  