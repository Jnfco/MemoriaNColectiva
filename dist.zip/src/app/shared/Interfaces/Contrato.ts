export class Contrato {
   
   idSindicato:string;
   content:string;
   isfinished:boolean;
   isNew:boolean;
   


}


