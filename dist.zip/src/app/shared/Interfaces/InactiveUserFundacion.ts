export interface InactiveUserFundacion {
    nombre: string;
    correo: string;
    pass: string;
    idFundacion:string;
    organization:string;
    isAdmin:boolean;
  }