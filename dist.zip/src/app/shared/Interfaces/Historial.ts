export class HistorialDocSindicato {

    idMiembro:string;
    idSindicato:string;
    nombre:string;
    correo:string;
    documento:string;
    fecha:string;
    idCambio:string;
}