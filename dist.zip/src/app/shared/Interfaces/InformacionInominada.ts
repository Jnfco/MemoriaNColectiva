export interface InformacionInominada{
  cargo:string;
  sueldo:number;
}
