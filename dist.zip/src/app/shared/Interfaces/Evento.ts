export class EventoSindicato {

    nombre:string;
    idSindicato:string;
    descripcion:string;
    fecha:string;
}

export class EventoFundacion{
    nombre:string;
    idSindicato:string;
    descripcion:string;
    fecha:string;
    idFundacion:string;
}