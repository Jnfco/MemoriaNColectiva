export interface UsuarioFundacion {
    nombre: string;
    correo: string;
    pass: string;
    idFundacion:string;
  }

  export interface Abogado {
    nombre:string;
    correo:string;
    posicion:number;
  }