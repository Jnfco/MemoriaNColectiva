export class postData{
  title: string;
  body: string;
  userId: number;
}

export interface respData {
  title: string;
  body: string;
  userId: number;
  id: number;
}
